var interface_a_map_geo_fence_district_region =
[
    [ "districtItem", "interface_a_map_geo_fence_district_region.html#aaf8398e863d18b9a3bf8691676f3a41e", null ],
    [ "polylinePoints", "interface_a_map_geo_fence_district_region.html#a6e6da3197d8f0db445bfbb0985ca4e0b", null ]
];