var searchData=
[
  ['monitoringgeofenceregionswithcustomid_3a',['monitoringGeoFenceRegionsWithCustomID:',['../interface_a_map_geo_fence_manager.html#a8f804f58c598fe184223a8ada1a59096',1,'AMapGeoFenceManager']]]
];
