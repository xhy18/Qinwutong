var searchData=
[
  ['radius',['radius',['../interface_a_map_geo_fence_circle_region.html#a95fa5cf0b68e75ff0a206b168537c86b',1,'AMapGeoFenceCircleRegion::radius()'],['../interface_a_map_location_circle_region.html#a379663cd2741d56dd55e84d82a4227aa',1,'AMapLocationCircleRegion::radius()']]],
  ['regeocodelanguage',['reGeocodeLanguage',['../interface_a_map_location_manager.html#a5626690eae35235ccfa464fc70fdb6a0',1,'AMapLocationManager']]],
  ['regeocodetimeout',['reGeocodeTimeout',['../interface_a_map_location_manager.html#ab63f44215a784ab7ee64cdfdd16fda53',1,'AMapLocationManager']]],
  ['regiontype',['regionType',['../interface_a_map_geo_fence_region.html#afc5cab5a28cd77268e4ad79569ee0ed0',1,'AMapGeoFenceRegion']]],
  ['removeallgeofenceregions',['removeAllGeoFenceRegions',['../interface_a_map_geo_fence_manager.html#a396e4e7829ede7f648b965eae6a195f5',1,'AMapGeoFenceManager']]],
  ['removegeofenceregionswithcustomid_3a',['removeGeoFenceRegionsWithCustomID:',['../interface_a_map_geo_fence_manager.html#a9d8e4a7ea09af05f01fd177baf9d92cf',1,'AMapGeoFenceManager']]],
  ['removethegeofenceregion_3a',['removeTheGeoFenceRegion:',['../interface_a_map_geo_fence_manager.html#ae2ac01c852052be47c3e4621685377cd',1,'AMapGeoFenceManager']]],
  ['requestlocationwithregeocode_3acompletionblock_3a',['requestLocationWithReGeocode:completionBlock:',['../interface_a_map_location_manager.html#a37c416c465f6d6919fc86ccfc8c124d3',1,'AMapLocationManager']]],
  ['requeststateforregion_3a',['requestStateForRegion:',['../interface_a_map_location_manager.html#ac8d58e113e7e140527455e68c2d455a6',1,'AMapLocationManager']]]
];
