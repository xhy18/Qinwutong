var searchData=
[
  ['geofenceregionswithcustomid_3a',['geoFenceRegionsWithCustomID:',['../interface_a_map_geo_fence_manager.html#a4179fc03664811511071c1bbbaf2f646',1,'AMapGeoFenceManager']]]
];
