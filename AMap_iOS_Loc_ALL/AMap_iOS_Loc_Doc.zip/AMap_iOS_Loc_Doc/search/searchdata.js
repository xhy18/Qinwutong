var indexSectionsWithContent =
{
  0: "_acdfghilmnprst",
  1: "a",
  2: "a",
  3: "_acdghilmprs",
  4: "a",
  5: "a",
  6: "a",
  7: "a",
  8: "acdfilmnprst",
  9: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties",
  9: "Macros"
};

