var searchData=
[
  ['identifier',['identifier',['../interface_a_map_geo_fence_region.html#a083c979efec477b2df7a5c50219cc0e5',1,'AMapGeoFenceRegion::identifier()'],['../interface_a_map_location_region.html#ab224cb1f12c26bb1c4d4bf8246e0f836',1,'AMapLocationRegion::identifier()']]]
];
