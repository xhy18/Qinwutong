var _a_map_geo_fence_region_obj_8h =
[
    [ "AMapGeoFenceRegion", "interface_a_map_geo_fence_region.html", "interface_a_map_geo_fence_region" ],
    [ "AMapGeoFenceCircleRegion", "interface_a_map_geo_fence_circle_region.html", "interface_a_map_geo_fence_circle_region" ],
    [ "AMapGeoFencePolygonRegion", "interface_a_map_geo_fence_polygon_region.html", "interface_a_map_geo_fence_polygon_region" ],
    [ "AMapGeoFencePOIRegion", "interface_a_map_geo_fence_p_o_i_region.html", "interface_a_map_geo_fence_p_o_i_region" ],
    [ "AMapGeoFenceDistrictRegion", "interface_a_map_geo_fence_district_region.html", "interface_a_map_geo_fence_district_region" ],
    [ "AMapGeoFenceRegionStatus", "_a_map_geo_fence_region_obj_8h.html#aa8b8afa50222e6aa9ca80e65ba3202f8", [
      [ "AMapGeoFenceRegionStatusUnknown", "_a_map_geo_fence_region_obj_8h.html#aa8b8afa50222e6aa9ca80e65ba3202f8a6b41ff0eee973c885f9beee9a8a2952d", null ],
      [ "AMapGeoFenceRegionStatusInside", "_a_map_geo_fence_region_obj_8h.html#aa8b8afa50222e6aa9ca80e65ba3202f8abf7b0dd1ebb16da37a78e29bd7bd212a", null ],
      [ "AMapGeoFenceRegionStatusOutside", "_a_map_geo_fence_region_obj_8h.html#aa8b8afa50222e6aa9ca80e65ba3202f8a7500f53643fa6f2c909e11c07d03f856", null ],
      [ "AMapGeoFenceRegionStatusStayed", "_a_map_geo_fence_region_obj_8h.html#aa8b8afa50222e6aa9ca80e65ba3202f8a52ec0d53d28154cce3bb9908f59a579e", null ]
    ] ],
    [ "AMapGeoFenceRegionType", "_a_map_geo_fence_region_obj_8h.html#a8f3cc661028920755b9a925fc41a3f0e", [
      [ "AMapGeoFenceRegionTypeCircle", "_a_map_geo_fence_region_obj_8h.html#a8f3cc661028920755b9a925fc41a3f0ea081309ac08f86ee6045e09bbe0121b1d", null ],
      [ "AMapGeoFenceRegionTypePolygon", "_a_map_geo_fence_region_obj_8h.html#a8f3cc661028920755b9a925fc41a3f0ea66045c3b6a0be482e71821b126f49f9d", null ],
      [ "AMapGeoFenceRegionTypePOI", "_a_map_geo_fence_region_obj_8h.html#a8f3cc661028920755b9a925fc41a3f0eaae4244c268a5c41c90921b20e4cb1227", null ],
      [ "AMapGeoFenceRegionTypeDistrict", "_a_map_geo_fence_region_obj_8h.html#a8f3cc661028920755b9a925fc41a3f0eaccaad15da5921f5e3c7629813e4394b6", null ]
    ] ]
];