var files =
[
    [ "AMapGeoFenceError.h", "_a_map_geo_fence_error_8h.html", "_a_map_geo_fence_error_8h" ],
    [ "AMapGeoFenceManager.h", "_a_map_geo_fence_manager_8h.html", "_a_map_geo_fence_manager_8h" ],
    [ "AMapGeoFenceRegionObj.h", "_a_map_geo_fence_region_obj_8h.html", "_a_map_geo_fence_region_obj_8h" ],
    [ "AMapLocationCommonObj.h", "_a_map_location_common_obj_8h.html", "_a_map_location_common_obj_8h" ],
    [ "AMapLocationKit.h", "_a_map_location_kit_8h.html", null ],
    [ "AMapLocationManager.h", "_a_map_location_manager_8h.html", "_a_map_location_manager_8h" ],
    [ "AMapLocationRegionObj.h", "_a_map_location_region_obj_8h.html", [
      [ "AMapLocationRegion", "interface_a_map_location_region.html", "interface_a_map_location_region" ],
      [ "AMapLocationCircleRegion", "interface_a_map_location_circle_region.html", "interface_a_map_location_circle_region" ],
      [ "AMapLocationPolygonRegion", "interface_a_map_location_polygon_region.html", "interface_a_map_location_polygon_region" ]
    ] ],
    [ "AMapLocationVersion.h", "_a_map_location_version_8h.html", "_a_map_location_version_8h" ]
];