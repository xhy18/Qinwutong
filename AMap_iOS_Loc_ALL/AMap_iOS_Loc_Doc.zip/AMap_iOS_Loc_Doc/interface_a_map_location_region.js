var interface_a_map_location_region =
[
    [ "containsCoordinate:", "interface_a_map_location_region.html#aa9606f46ed1965fa4e1d51e16f184899", null ],
    [ "initWithIdentifier:", "interface_a_map_location_region.html#a317409b5da050f7f83f3082b87fbe868", null ],
    [ "identifier", "interface_a_map_location_region.html#ab224cb1f12c26bb1c4d4bf8246e0f836", null ],
    [ "notifyOnEntry", "interface_a_map_location_region.html#abc6daf913a7faefbd4ccb49fde92e982", null ],
    [ "notifyOnExit", "interface_a_map_location_region.html#a8dcf30b8ee8a118874c94575423cb845", null ]
];