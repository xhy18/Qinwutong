var _a_map_geo_fence_manager_8h =
[
    [ "AMapGeoFenceManager", "interface_a_map_geo_fence_manager.html", "interface_a_map_geo_fence_manager" ],
    [ "<AMapGeoFenceManagerDelegate >", "protocol_a_map_geo_fence_manager_delegate_01-p.html", "protocol_a_map_geo_fence_manager_delegate_01-p" ],
    [ "AMapGeoFenceActiveAction", "_a_map_geo_fence_manager_8h.html#ad62c58e20df8610a243d895e80e890dd", [
      [ "AMapGeoFenceActiveActionNone", "_a_map_geo_fence_manager_8h.html#ad62c58e20df8610a243d895e80e890dda1ce52d51c1ea2700b3e17a313ec19620", null ],
      [ "AMapGeoFenceActiveActionInside", "_a_map_geo_fence_manager_8h.html#ad62c58e20df8610a243d895e80e890ddab73e3b4c449fe433f75d140b535c5cbd", null ],
      [ "AMapGeoFenceActiveActionOutside", "_a_map_geo_fence_manager_8h.html#ad62c58e20df8610a243d895e80e890dda2fbd1f8a038a9c73d3ef62e5c5d7bb4c", null ],
      [ "AMapGeoFenceActiveActionStayed", "_a_map_geo_fence_manager_8h.html#ad62c58e20df8610a243d895e80e890dda3e9e0f64a0777c7568298a2cb867668c", null ]
    ] ],
    [ "AMapGeoFenceRegionActiveStatus", "_a_map_geo_fence_manager_8h.html#a5d4592b537ff7ece3e2f5f53a90a2af8", [
      [ "AMapGeoFenceRegionActiveUNMonitor", "_a_map_geo_fence_manager_8h.html#a5d4592b537ff7ece3e2f5f53a90a2af8acc8511adc1c63ff3cb0c117a51baf766", null ],
      [ "AMapGeoFenceRegionActiveMonitoring", "_a_map_geo_fence_manager_8h.html#a5d4592b537ff7ece3e2f5f53a90a2af8ac473b947123a356b07a6e5876c20b16c", null ],
      [ "AMapGeoFenceRegionActivePaused", "_a_map_geo_fence_manager_8h.html#a5d4592b537ff7ece3e2f5f53a90a2af8a42298ea4a70e94634ed9291d59da6fac", null ]
    ] ]
];