var protocol_a_map_json_manual_serialization_01_p =
[
    [ "manualDeserializationJsonData:forInfo:", "protocol_a_map_json_manual_serialization_01-p.html#a3c2ba0fa9e99a9805560b860578a7036", null ],
    [ "manualSerializeObjectForInfo:", "protocol_a_map_json_manual_serialization_01-p.html#a64607b05d7cbfb2b259f0868c2ab0605", null ]
];