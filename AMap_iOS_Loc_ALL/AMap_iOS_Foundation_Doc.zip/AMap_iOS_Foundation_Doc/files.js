var files =
[
    [ "AMapFoundationKit.h", "_a_map_foundation_kit_8h.html", null ],
    [ "AMapFoundationVersion.h", "_a_map_foundation_version_8h.html", "_a_map_foundation_version_8h" ],
    [ "AMapServices.h", "_a_map_services_8h.html", [
      [ "AMapServices", "interface_a_map_services.html", "interface_a_map_services" ]
    ] ],
    [ "AMapURLSearch.h", "_a_map_u_r_l_search_8h.html", [
      [ "AMapURLSearch", "interface_a_map_u_r_l_search.html", null ]
    ] ],
    [ "AMapURLSearchConfig.h", "_a_map_u_r_l_search_config_8h.html", [
      [ "AMapNaviConfig", "interface_a_map_navi_config.html", "interface_a_map_navi_config" ],
      [ "AMapRouteConfig", "interface_a_map_route_config.html", "interface_a_map_route_config" ],
      [ "AMapPOIConfig", "interface_a_map_p_o_i_config.html", "interface_a_map_p_o_i_config" ]
    ] ],
    [ "AMapURLSearchType.h", "_a_map_u_r_l_search_type_8h.html", "_a_map_u_r_l_search_type_8h" ],
    [ "AMapUtility.h", "_a_map_utility_8h.html", "_a_map_utility_8h" ],
    [ "NSMutableArray+AMapSafe.h", "_n_s_mutable_array_09_a_map_safe_8h.html", [
      [ "NSMutableArray", "interface_n_s_mutable_array.html", "interface_n_s_mutable_array" ]
    ] ],
    [ "NSMutableDictionary+AMapSafe.h", "_n_s_mutable_dictionary_09_a_map_safe_8h.html", [
      [ "NSMutableDictionary", "interface_n_s_mutable_dictionary.html", "interface_n_s_mutable_dictionary" ]
    ] ],
    [ "NSObject+AMapJsonSerialization.h", "_n_s_object_09_a_map_json_serialization_8h.html", "_n_s_object_09_a_map_json_serialization_8h" ]
];