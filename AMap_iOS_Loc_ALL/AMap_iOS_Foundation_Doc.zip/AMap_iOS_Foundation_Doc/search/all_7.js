var searchData=
[
  ['manualdeserializationjsondata_3aforinfo_3a',['manualDeserializationJsonData:forInfo:',['../protocol_a_map_json_manual_serialization_01-p.html#a3c2ba0fa9e99a9805560b860578a7036',1,'AMapJsonManualSerialization -p']]],
  ['manualserializeobjectforinfo_3a',['manualSerializeObjectForInfo:',['../protocol_a_map_json_manual_serialization_01-p.html#a64607b05d7cbfb2b259f0868c2ab0605',1,'AMapJsonManualSerialization -p']]]
];
