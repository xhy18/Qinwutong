var searchData=
[
  ['rightbottomcoordinate',['rightBottomCoordinate',['../interface_a_map_p_o_i_config.html#ae32c58f77dcd9b66be27beb5fecc1d0a',1,'AMapPOIConfig']]],
  ['routetype',['routeType',['../interface_a_map_route_config.html#adbcc804df0a4e9d6c16a864a67cb82b5',1,'AMapRouteConfig']]]
];
